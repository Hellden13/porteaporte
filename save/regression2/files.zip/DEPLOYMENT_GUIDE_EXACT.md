# 🚀 GUIDE DEPLOYMENT EXACT - PorteàPorte Corrections

**Auteur**: Claude Codex  
**Date**: May 11, 2026  
**Durée estimée**: 1h30 (si tout OK du premier coup)  
**Risk**: Bas (changements petits et testables)

---

## 📋 FICHIERS À MODIFIER / CRÉER

```
MODIFIER:
  C:\Users\User\OneDrive\Desktop\Site\vercel.json
  C:\Users\User\OneDrive\Desktop\Site\api\notifier.js

CRÉER:
  C:\Users\User\OneDrive\Desktop\Site\api\test-email.js
  C:\Users\User\OneDrive\Desktop\Site\api\admin-update-driver-status.js
```

---

## ✅ ÉTAPE 1: VÉRIFIER LES ENV VARS EN VERCEL DASHBOARD (5 min)

**URL**: https://vercel.com/dashboard

1. Cliquer sur **project-crp3i**
2. Aller à **Settings** (onglet)
3. Cliquer sur **Environment Variables**

**Vérifier que CES variables existent** (case-sensitive):

- [ ] `SUPABASE_URL` = `https://miqrircrfpzkmvvacgwt.supabase.co`
- [ ] `SUPABASE_ANON_KEY` = (votre clé anon de Supabase)
- [ ] `SENDGRID_API_KEY` = `SG.xxxxxxxxxxxxxxxxxxxxxxxx` ← DOIT COMMENCER PAR "SG."
- [ ] `FROM_EMAIL` = `notifications@porteaporte.site` (ou autre)
- [ ] `ADMIN_EMAIL` = `denismorneaubtc@gmail.com` (ou votre email)
- [ ] `INTERNAL_API_SECRET` = (chaîne sécurisée d'au moins 32 caractères)
- [ ] `STRIPE_SECRET_KEY` = `sk_live_xxxxx` (clé Stripe secrète)
- [ ] `STRIPE_WEBHOOK_SECRET` = `whsec_xxxxx` (secret webhook Stripe)

**Si MANQUANT**: Cliquer **Add** et remplir. Ne pas oublier de **Save** (bouton bas de la page).

**⚠️ IMPORTANT**: Après l'ajout/modification, Vercel redéploie automatiquement. Attendre ~2-3 min avant de tester.

---

## ✅ ÉTAPE 2: METTRE À JOUR vercel.json (10 min)

**Fichier**: `C:\Users\User\OneDrive\Desktop\Site\vercel.json`

### Option A: Remplacer entièrement (recommandé)

1. Ouvrir le fichier dans VS Code
2. Sélectionner tout (Ctrl+A)
3. Supprimer
4. Copier le contenu complet de `/home/claude/vercel.json.CORRECTED`
5. Coller et sauvegarder (Ctrl+S)

### Option B: Ajouter section `env` manuellement

Après la ligne `"trailingSlash": false,` ajouter:

```json
"env": {
    "SUPABASE_URL": "@supabase_url",
    "SUPABASE_ANON_KEY": "@supabase_anon_key",
    "SENDGRID_API_KEY": "@sendgrid_api_key",
    "FROM_EMAIL": "@from_email",
    "ADMIN_EMAIL": "@admin_email",
    "INTERNAL_API_SECRET": "@internal_api_secret",
    "STRIPE_SECRET_KEY": "@stripe_secret_key",
    "STRIPE_WEBHOOK_SECRET": "@stripe_webhook_secret",
    "STRIPE_ACCOUNT_ID": "@stripe_account_id",
    "ALLOWED_ORIGIN": "@allowed_origin"
},
```

Et dans la section `"rewrites"`, ajouter ces 3 lignes AVANT les autres rewrites:

```json
{
    "source": "/api/test-email",
    "destination": "/api/test-email.js"
},
{
    "source": "/api/admin-update-driver-status",
    "destination": "/api/admin-update-driver-status.js"
},
{
    "source": "/api/create-litige",
    "destination": "/api/create-litige.js"
},
```

**Vérifier la syntaxe JSON** (pas d'erreur de comma):
```bash
# Dans VS Code: Ctrl+Shift+P → Format Document
# Ou vérifier visuellement pour les accents rouges
```

Sauvegarder (Ctrl+S).

---

## ✅ ÉTAPE 3: MODIFIER api/notifier.js (15 min)

**Fichier**: `C:\Users\User\OneDrive\Desktop\Site\api\notifier.js`

### Ajouter la nouvelle fonction sendAuthConfirmationEmail()

**Où**: Avant la fonction `sendEmail()` (environ ligne 150)

**Rechercher**: Ouvrir Find (Ctrl+F) et chercher `async function sendEmail(`

**Avant cette fonction**, insérer le contenu complet de `/home/claude/NOTIFIER_NEW_FUNCTION.js`

(C'est la fonction `sendAuthConfirmationEmail()` avec son HTML email)

### Vérifier l'appel de cette fonction

**Ligne ~124**, vérifier que c'est maintenant:

```javascript
if (type === 'auth_confirmation') {
    const result = await sendAuthConfirmationEmail(data, {
        sendgridKey: SENDGRID_API_KEY,
        fromEmail: FROM_EMAIL,
        fromName: FROM_NAME
    });
    return res.status(result.ok ? 200 : 500).json({
        success: result.ok,
        sent: result.ok ? 1 : 0,
        error: result.ok ? undefined : (result.error || 'Courriel de confirmation non envoye')
    });
}
```

✅ Sauvegarder (Ctrl+S).

---

## ✅ ÉTAPE 4: CRÉER api/test-email.js (5 min)

**Fichier NOUVEAU**: `C:\Users\User\OneDrive\Desktop\Site\api\test-email.js`

1. Créer un nouveau fichier (Ctrl+N dans VS Code)
2. Sauvegarder sous `api/test-email.js`
3. Copier-coller le contenu complet de `/home/claude/api_test-email.js`
4. Sauvegarder (Ctrl+S)

**Vérifier**: Le fichier doit être en root du dossier `api/`.

---

## ✅ ÉTAPE 5: CRÉER api/admin-update-driver-status.js (5 min)

**Fichier NOUVEAU**: `C:\Users\User\OneDrive\Desktop\Site\api\admin-update-driver-status.js`

1. Créer un nouveau fichier
2. Sauvegarder sous `api/admin-update-driver-status.js`
3. Copier-coller le contenu complet de `/home/claude/api_admin-update-driver-status.js`
4. Sauvegarder (Ctrl+S)

---

## 🧪 ÉTAPE 6: TESTER LOCALEMENT (15 min)

**Lancer un serveur local** (sans build Node):

### Option A: Python
```bash
cd "C:\Users\User\OneDrive\Desktop\Site"
python -m http.server 8000
# Puis visiter: http://localhost:8000/login.html
```

### Option B: npx http-server
```bash
cd "C:\Users\User\OneDrive\Desktop\Site"
npx http-server . -p 8000
```

### Option C: VS Code Live Server
```
Clic droit sur login.html → "Open with Live Server"
```

**Tester les fichiers critiques**:

1. **login.html** doit charger sans erreur
   - Ouvrir http://localhost:8000/login.html
   - Ouvrir console (F12)
   - Aucune erreur "Cannot find module" ou syntax error

2. **Vérifier la syntaxe JS** des nouveaux fichiers
   - VS Code doit pas afficher d'erreurs rouges
   - ou: `npm exec eslint -- api/test-email.js` (si ESLint installé)

3. **Tester signup → vérifier que emailRedirectTo n'a pas d'erreur**
   - Chercher dans login.html: `emailRedirectTo`
   - Doit être: `/login.html?confirmed=1`

**Afficher les logs**:
```javascript
// Dans console du navigateur (F12):
localStorage.getItem('DEBUG_EMAILS');  // Si set localement
```

---

## 🚀 ÉTAPE 7: COMMITTER & POUSSER À GIT (5 min)

Vous avez un Git repo ?

```bash
cd "C:\Users\User\OneDrive\Desktop\Site"

# Vérifier les changements
git status

# Ajouter les fichiers
git add vercel.json api/notifier.js api/test-email.js api/admin-update-driver-status.js

# Committer
git commit -m "Fix: Email config, add SendGrid fallback, admin driver approval

- Add env vars section to vercel.json
- Add sendAuthConfirmationEmail() to notifier.js
- Create api/test-email.js for SendGrid diagnostics
- Create api/admin-update-driver-status.js for admin approval workflow
- Add rewrites in vercel.json for new endpoints

Fixes:
- SENDGRID_API_KEY now properly exposed to api/ functions
- Email confirmations now have fallback via SendGrid
- Admin can now approve/reject drivers and send verified card
- Diagnostic endpoint to troubleshoot email issues"

# Pousser
git push origin main
# (ou develop, selon votre workflow)
```

---

## ✅ ÉTAPE 8: VÉRIFIER LE DÉPLOIEMENT VERCEL (10 min)

**URL**: https://vercel.com/project-crp3i

1. **Attendre le redéploiement automatique** (~2-3 min après le git push)
2. **Voir les logs**:
   - Cliquer sur le dernier déploiement
   - Onglet **Deployments** → cliquer sur le plus récent
   - Voir "Building..." puis "Ready"
3. **Vérifier les logs de build**:
   - Chercher des erreurs "ENOENT" (fichier manquant)
   - Chercher des erreurs de syntaxe JSON
4. **Tester l'endpoint diagnostic**:
   ```bash
   curl -X POST https://porteaporte.site/api/test-email \
     -H "Content-Type: application/json" \
     -d '{"email":"test@example.com"}'
   ```
   Réponse attendue:
   ```json
   {
     "success": false,
     "error": "Configuration manquante",
     "missing": ["SENDGRID_API_KEY"]
   }
   ```
   ou
   ```json
   {
     "success": true,
     "message": "Email envoyé avec succès",
     "email_masked": "t***@example.com"
   }
   ```

Si erreur "Configuration manquante", c'est que les env vars Vercel ne sont pas présentes. Retour à **ÉTAPE 1**.

---

## 🔬 ÉTAPE 9: TESTER SIGNUP EMAIL (10 min)

### Test 1: Resend confirmation

1. Aller à https://porteaporte.site/login.html
2. Ouvrir console (F12)
3. Entrer dans le formulaire login
4. Si erreur "Pas reçu l'email", cliquer "Renvoyer"
5. **Vérifier l'inbox** de l'email testé (vérifier Spam/Indesirables)

**Succès**: Email reçu dans les 30 secondes avec lien de confirmation

**Echec**: Affiche erreur OR aucun email reçu après 2 min
- Vérifier SENDGRID_API_KEY en Vercel → settings
- Tester /api/test-email directement
- Vérifier les logs Vercel pour l'erreur exact

### Test 2: Request driver card

1. Se connecter avec compte livreur
2. Aller à https://porteaporte.site/livreur.html
3. Cliquer "Demander ma carte"
4. **Vérifier l'inbox**: Doit recevoir la carte provisoire

**Succès**: Email reçu avec la carte + explications

**Echec**: Pas d'email OU message d'erreur
- Vérifier que `role === 'livreur'` dans Supabase
- Vérifier que `email` est présent dans le profile
- Vérifier logs Vercel

---

## 🎯 ÉTAPE 10: TESTER ADMIN APPROVAL (5 min)

Vous avez admin dashboard ? (gestion-pp-8k2x.html ?)

1. Se connecter avec compte admin
2. Chercher un livreur en statut `pending_review`
3. Cliquer "Approuver" (ou bouton équivalent)

**Succès**:
- Statut change à `verified` ✅
- Livreur reçoit email avec carte vérifiée ✅

**Echec**:
- Erreur 403 "Accès refusé" = pas admin
- Erreur 500 = check Vercel logs
- Pas d'email = check /api/test-email

---

## ✅ CHECKLIST FINALE

Avant de dire "production-ready":

- [ ] vercel.json a section `env` avec tous les @references
- [ ] Vercel Dashboard Settings → Environment Variables a toutes les clés
- [ ] api/notifier.js a fonction `sendAuthConfirmationEmail()`
- [ ] api/test-email.js créé et syntaxe OK
- [ ] api/admin-update-driver-status.js créé et syntaxe OK
- [ ] Git commit et push effectué
- [ ] Vercel a redéployé (voir Deployments "Ready")
- [ ] Test-email retourne succès (ou erreur spécifique, pas "undefined")
- [ ] Signup → email reçu dans les 30s
- [ ] Request-card → email reçu dans les 30s
- [ ] Admin approve → livreur reçoit carte vérifiée

---

## 🚨 TROUBLESHOOTING

### Problème: "SENDGRID_API_KEY manquante"
**Solution**: Vérifier Vercel Dashboard → Settings → Environment Variables
- Clé doit commencer par "SG."
- Doit être présente ET non-vide

### Problème: "Fonction sendAuthConfirmationEmail is not defined"
**Solution**: Vous avez peut-être collé au mauvais endroit dans notifier.js
- Doit être AVANT la fonction `sendEmail()`
- Chercher la ligne `async function sendEmail(` et ajouter avant

### Problème: "GET /api/test-email" au lieu de "POST"
**Solution**: Vérifier que vercel.json a la rewrite `/api/test-email → /api/test-email.js`
- Et que vous appelez POST (pas GET) depuis le frontend

### Problème: Email non reçu après 2 minutes
**Solution**: Vérifier:
1. Vérifier spam/indesirables
2. Tester /api/test-email avec l'email manuel
3. Vérifier `FROM_EMAIL` est domaine autorisé (porteaporte.site?)
4. Vérifier SendGrid limits (100/jour gratuit)
5. Vérifier logs Vercel pour l'erreur exact

### Problème: Carte livreur toujours "provisoire"
**Solution**: Livreur doit être en statut `verified`
- Admin doit passer au statut verified avec /api/admin-update-driver-status
- Après ça, la carte doit dire "Vérifiée ✅"

---

## 📊 RÉSUMÉ TEMPS

| Étape | Durée | Notes |
|-------|-------|-------|
| 1. Vérifier env vars | 5 min | Vercel Dashboard |
| 2. Mettre à jour vercel.json | 10 min | Copier ou éditer |
| 3. Modifier api/notifier.js | 15 min | Ajouter fonction |
| 4. Créer test-email.js | 5 min | Nouveau fichier |
| 5. Créer admin-update-driver.js | 5 min | Nouveau fichier |
| 6. Tester localement | 15 min | http://localhost:8000 |
| 7. Git commit + push | 5 min | git push origin main |
| 8. Vérifier Vercel | 10 min | Attendre "Ready" |
| 9. Tester signup email | 10 min | Vérifier inbox |
| 10. Tester admin approval | 5 min | Admin dashboard |
| **TOTAL** | **1h30** | Si tout OK du premier coup |

---

## ✨ APRÈS DEPLOYMENT

Prochaines priorités (non bloquantes pour maintenant):

1. **Litiges / Assurance** - Créer api/create-litige.js (backend pour réclamations)
2. **Nettoyage** - Lister et supprimer fichiers test/prototypes
3. **Carte interactif** - Intégrer Google Maps pour livreurs
4. **Vérifications supplémentaires** - Tests de sécurité RLS Supabase
5. **Monitoring** - Setup alerts pour failures email en production

---

**Vous êtes prêt ? 🚀**

Si vous avez une question, revenez ici. Je peux aussi vous guider pas-à-pas sur Zoom si nécessaire!
