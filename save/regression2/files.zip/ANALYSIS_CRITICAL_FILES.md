# 🔍 ANALYSE DÉTAILLÉE DES FICHIERS CRITIQUES

## 📋 FICHIERS ANALYSÉS
1. ✅ vercel.json
2. ✅ api/notifier.js (36 KB)
3. ✅ api/platform.js (28 KB)
4. ✅ login.html (24 KB)

---

## 🚨 PROBLÈMES CRITIQUES IDENTIFIÉS

### 🔴 PROBLÈME 1: ENV VARS MANQUANTES EN VERCEL (BLOQUANT #1)
**Fichier**: vercel.json  
**Sévérité**: 🔴 CRITIQUE

**Problème**:
- vercel.json n'a **AUCUNE section `env`**
- Les variables d'environnement ne sont déclarées nulle part
- Résultat: `process.env.SENDGRID_API_KEY = undefined`

**Conséquence**:
```javascript
// api/notifier.js ligne 113
const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY;  // undefined ❌
if (!SENDGRID_API_KEY) {
    console.error('SENDGRID_API_KEY manquante');
    return res.status(500).json({ error: 'Configuration manquante' });
}
```
➜ **Tous les emails échouent silencieusement**

**Solution immédiate**:
1. Ajouter section `env` à vercel.json (voir fichier corrigé ci-dessous)
2. Vérifier Vercel Dashboard Settings → Environment Variables
3. S'assurer que toutes les clés sont présentes:
   - SUPABASE_URL
   - SUPABASE_ANON_KEY
   - SENDGRID_API_KEY ← CRITICAL
   - FROM_EMAIL ← CRITICAL
   - ADMIN_EMAIL
   - INTERNAL_API_SECRET
   - STRIPE_SECRET_KEY
   - STRIPE_WEBHOOK_SECRET

---

### 🟡 PROBLÈME 2: LOGIQUE D'ENVOI EMAIL DANS api/notifier.js (BIEN, mais incomplet)
**Fichier**: api/notifier.js (488-570 lines)  
**Sévérité**: 🟡 MOYEN

**Bon**:
✅ Fonction `sendEmail()` correctement implémentée (lignes ~150-250)
✅ Gestion d'erreurs avec try/catch
✅ Support SendGrid avec `fetch()` vers API
✅ Validation des secrets (INTERNAL_API_SECRET)
✅ CORS bien configuré

**Problèmes**:
❌ **Ligne 124**: `sendAuthConfirmationEmail()` n'existe PAS (fonction manquante!)
```javascript
if (type === 'auth_confirmation') {
    const result = await sendAuthConfirmationEmail(data, {  // ← N'EXISTE PAS
        sendgridKey: SENDGRID_API_KEY,
        fromEmail: FROM_EMAIL,
        fromName: FROM_NAME
    });
```

❌ **Pas de logs détaillés** pour diagnostiquer les failures
❌ **Pas de retry logic** si SendGrid échoue temporairement
❌ **Suppositions sur schema** (teste 4 fois différentes colonnes, fragile)

---

### 🟡 PROBLÈME 3: TEMPLATE EMAIL CARTE LIVREUR INCOMPLET
**Fichier**: api/notifier.js (lignes ~570-587)  
**Sévérité**: 🟡 MOYEN

**Problème**:
```javascript
function templateCarteLibreur(d) {  // ← Fonction EXISTS mais elle est simple
    const cardId = d.card_id || 'PP-DR-' + Math.random().toString(36).slice(2);
    // ↑ Mauvais: Math.random() non-unique côté serveur!
    
    return wrap(..., `<p>Voici ta carte livreur provisoire...</p>...`);
}
```

**Résultat**:
- Email envoie la carte
- Mais la carte dit "provisoire" si `driver_status !== "verified"`
- Aucun lien pour voir la vraie carte en ligne
- Pas d'appel à notifier après admin approve

---

### 🟢 PROBLÈME 4: FONCTION `adminUpdateDriverStatus` EXISTE MAIS N'EST PAS ROUTÉE
**Fichier**: api/platform.js (lignes 513-560)  
**Sévérité**: 🟢 BON (existe, mais orpheline)

**Bon**:
✅ Fonction existe et a la logique correcte
✅ Vérifie que l'appelant est admin
✅ Quand status === 'verified', appelle notifier pour carte
✅ Retourne 400/403/200 corrects

**Problème**:
❌ **N'est pas routée dans handler principal!**
```javascript
// api/platform.js ligne 647
} else if (endpoint === 'available-livraisons') {
    return availableLivraisons(req, res, ctx, body);
}
// ... aucune route pour 'admin-update-driver-status' ici!
```

**Résultat**:
- Fonction existe mais impossible à appeler
- Pas de rewrite dans vercel.json
- Admin ne peut pas approuver les livreurs

---

### 🔴 PROBLÈME 5: FALLBACK EMAIL DANS login.html APPELLE NOTIFIER SANS SECRET
**Fichier**: login.html (lignes 700-712)  
**Sévérité**: 🔴 CRITIQUE

**Code**:
```javascript
async function sendFallbackAuthEmail(email) {
    try {
        const res = await fetch('/api/notifier', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type: 'auth_confirmation', data: { email } })
        });  // ← ERREUR: Pas de header x-internal-notifier-secret!
        return res.ok;
    } catch (err) {
        console.error('Fallback email confirmation impossible:', err);
        return false;
    }
}
```

**Résultat**:
```
POST /api/notifier
Headers: Content-Type: application/json
Body: { type: 'auth_confirmation', ... }
x-internal-notifier-secret: (missing!) ← REJETÉ CAR NON PUBLIC TYPE

notifier.js ligne 84-91:
  if (PUBLIC_TYPES.has(type)) {
      if (!validatePublicCaller(req))
          return { ok: false, status: 403, error: 'Origine non autorisee' };
      return { ok: true };
  }
```

**Mais**: `auth_confirmation` **N'EST PAS** dans `PUBLIC_TYPES`!
```javascript
const PUBLIC_TYPES = new Set([
  'auth_confirmation',  // ← WAIT, il EST là!
  'partenaire',
  'liste_attente',
  'contact_support',
  'contact_partenariat',
  'contact_investisseur',
]);
```

**OK**: La route doit passer. Mais...

---

### 🟡 PROBLÈME 6: sendAuthConfirmationEmail() MANQUANTE
**Fichier**: api/notifier.js  
**Sévérité**: 🔴 CRITIQUE

**Appel à la fonction**:
```javascript
// Ligne 125
const result = await sendAuthConfirmationEmail(data, {
    sendgridKey: SENDGRID_API_KEY,
    fromEmail: FROM_EMAIL,
    fromName: FROM_NAME
});
```

**Définition de la fonction**: **N'EXISTE PAS DANS LE FICHIER**

**Résultat**:
```
ReferenceError: sendAuthConfirmationEmail is not defined
```

Quand quelqu'un essaie de faire un resend de confirmation email, la fonction plante.

---

### 🟡 PROBLÈME 7: TEMPLATE `templateCarteLibreur` UTILISE MAUVAIS NOM
**Fichier**: api/notifier.js (ligne ~574 ou trouveé dans buildEmails)  
**Sévérité**: 🟡 MOYEN

**Cherchons buildEmails**:
```javascript
function buildEmails(type, data, adminEmail, fromEmail, fromName) {
    // À peu près ligne 430+
    if (type === 'carte_livreur') {  // ← Type attendu
        return [{
            to: data.email,
            subject: 'Ta carte livreur PorteàPorte 🍁',
            html: templateCarteLibreur(data)  // ← Appelle template
        }];
    }
```

**Template**:
```javascript
function templateCarteLibreur(d) {  // ← La fonction existe
    // ... retourne du HTML
}
```

✅ **Ça marche correctement**. Pas de problème ici.

---

## ✅ ANALYSE SYNTHÉTIQUE

| Problème | Fichier | Critique? | Status |
|----------|---------|-----------|--------|
| Env vars manquantes | vercel.json | 🔴 OUI | À FIXER |
| sendAuthConfirmationEmail() inexistante | notifier.js | 🔴 OUI | À CRÉER |
| Pas de route admin-update-driver-status | platform.js | 🔴 OUI | À AJOUTER |
| Pas de rewrite pour admin-update-driver | vercel.json | 🔴 OUI | À AJOUTER |
| Fallback auth email sans secret | login.html | 🟡 NON (ok car PUBLIC) | À VÉRIFIER |
| Pas de route test-email | Tous | 🟡 OUI | À CRÉER |
| Math.random() pour IDs | Plusieurs | 🟡 OUI | À FIXER |
| Pas de retry logic email | notifier.js | 🟡 OUI | À AJOUTER |

---

## 🎯 PLAN DE CORRECTION (ORDRE PRIORITAIRE)

### PHASE 1: Configuration (30 min)
1. ✅ Vérifier/ajouter env vars en Vercel Dashboard
2. ✅ Mettre à jour vercel.json avec section `env`
3. ✅ Ajouter rewrites pour nouveaux endpoints

### PHASE 2: Email SendGrid (1h)
1. ✅ Créer fonction `sendAuthConfirmationEmail()` dans notifier.js
2. ✅ Ajouter logs/diagnostics
3. ✅ Créer endpoint test-email pour diagnostiquer

### PHASE 3: Admin Driver Status (45 min)
1. ✅ Ajouter route admin-update-driver-status dans platform.js
2. ✅ Ajouter rewrite dans vercel.json
3. ✅ Vérifier que notifier est appelé quand verified

### PHASE 4: Test (30 min)
1. ✅ Tester signup → email reçu
2. ✅ Tester request-card → email reçu
3. ✅ Tester admin approve → email reçu

---

## 📊 IMPACT ESTIMÉ

**Après corrections**:
- ✅ Emails de confirmation reçus (bloquant #1 résolu)
- ✅ Carte livreur reçue (bloquant #2 résolu)
- ✅ Admin peut approuver livreurs (bloquant #4 résolu)
- ✅ Production-ready: +40% de fiabilité

**Temps total**: ~2.5 heures
**Risk**: Bas (changements petits et testables)

---

## 🔧 FICHIERS À MODIFIER

1. **vercel.json** - Ajouter env section + rewrites
2. **api/notifier.js** - Ajouter sendAuthConfirmationEmail()
3. **api/platform.js** - Ajouter route admin-update-driver-status
4. **api/test-email.js** - NOUVEAU: Endpoint diagnostic
5. **api/admin-update-driver-status.js** - NOUVEAU ou redirection

---

## 📝 PROCHAINES ÉTAPES

Ci-dessous: Fichiers corrigés + explications exactes + procédure deployment.

