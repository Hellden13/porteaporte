/**
 * API: /api/test-email
 * 
 * Endpoint diagnostic pour tester la configuration SendGrid.
 * Utile pour vérifier que les env vars sont présentes sans les exposer.
 * 
 * Sécurité: Accepte les requêtes du site seulement, retourne des infos génériques.
 * 
 * Utilisation:
 *   POST /api/test-email
 *   Body: { email: "test@example.com", type: "simple" }
 * 
 * Réponse:
 *   { success: true, message: "Email envoyé", email_masked: "t***@example.com" }
 *   ou
 *   { success: false, error: "SENDGRID_API_KEY manquante", status: 500 }
 */

module.exports = async function handler(req, res) {
  // CORS
  const allowOrigin = process.env.ALLOWED_ORIGIN || 'https://porteaporte.site';
  res.setHeader('Access-Control-Allow-Origin', allowOrigin);
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Méthode non autorisée' });
  }

  // Vérifier que c'est du site même
  const origin = String(req.headers.origin || req.headers.referer || '');
  const allowedOrigin = (process.env.ALLOWED_ORIGIN || 'https://porteaporte.site').replace(/\/$/, '');
  if (origin && !origin.startsWith(allowedOrigin)) {
    return res.status(403).json({ error: 'Origine non autorisée' });
  }

  const { email, type = 'simple' } = req.body || {};

  // Validation minimal
  if (!email || !email.includes('@')) {
    return res.status(400).json({ error: 'Email invalide' });
  }

  // Vérifier la config
  const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY;
  const FROM_EMAIL = process.env.FROM_EMAIL || 'notifications@porteaporte.site';

  if (!SENDGRID_API_KEY) {
    return res.status(500).json({
      success: false,
      error: 'Configuration manquante',
      missing: ['SENDGRID_API_KEY'],
      hint: 'Vérifier les env vars en Vercel → Settings → Environment Variables'
    });
  }

  if (SENDGRID_API_KEY.length < 10) {
    return res.status(500).json({
      success: false,
      error: 'SENDGRID_API_KEY invalide (trop court)',
      hint: 'La clé doit commencer par "SG."'
    });
  }

  if (!FROM_EMAIL.includes('@')) {
    return res.status(500).json({
      success: false,
      error: 'FROM_EMAIL invalide',
      hint: `FROM_EMAIL=${FROM_EMAIL} n'est pas un email valide`
    });
  }

  try {
    // Envoyer un email de test simple
    const subject = 'Test PorteàPorte 🍁 - Vérification SendGrid';
    const html = `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="font-family: Arial; background: #0A0C0F; color: #E8EAED; padding: 20px;">
  <div style="max-width: 500px; margin: 0 auto; background: #12151A; padding: 30px; border-radius: 10px; border: 1px solid #1F242C;">
    <h1 style="color: #B8F53E; margin-top: 0;">✅ Email de Test</h1>
    <p>Cet email vérifie que <strong>SendGrid fonctionne correctement</strong>.</p>
    <p style="color: #A0A3A8; font-size: 13px; margin-top: 20px;">
      Timestamp: ${new Date().toISOString()}
    </p>
    <hr style="border: none; border-top: 1px solid #1F242C;">
    <p style="font-size: 12px; color: #888;">PorteàPorte · La livraison collaborative québécoise 🍁</p>
  </div>
</body>
</html>
    `.trim();

    // Appeler SendGrid API
    const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${SENDGRID_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        personalizations: [
          {
            to: [{ email }],
            subject,
          },
        ],
        from: {
          email: FROM_EMAIL,
          name: 'PorteàPorte Test 🍁',
        },
        content: [
          {
            type: 'text/html',
            value: html,
          },
        ],
        reply_to: {
          email: 'support@porteaporte.site',
          name: 'Support PorteàPorte',
        },
      }),
    });

    const responseData = await response.json().catch(() => ({}));

    if (response.ok || response.status === 202) {
      // Masquer l'email pour la réponse
      const emailMasked = email.replace(/^(.)(.*)(@.*)$/, '$1***$3');
      return res.status(200).json({
        success: true,
        message: 'Email envoyé avec succès',
        email_masked: emailMasked,
        status: response.status,
        sendgrid_status: 'OK',
      });
    }

    // Erreur SendGrid
    const errorMsg = responseData?.errors?.[0]?.message || responseData?.error || response.statusText;
    return res.status(500).json({
      success: false,
      error: 'SendGrid a rejeté l\'email',
      details: errorMsg || 'Erreur inconnue',
      status: response.status,
      hint: 'Vérifier la clé API et l\'email FROM',
    });

  } catch (err) {
    console.error('[test-email] Erreur:', err.message);
    return res.status(500).json({
      success: false,
      error: 'Erreur interne SendGrid',
      details: err.message,
      hint: 'Vérifier les logs Vercel pour plus de détails',
    });
  }
};

/**
 * UTILISATION EN FRONTEND (exemple):
 * 
 * async function testSendGrid(email) {
 *   try {
 *     const res = await fetch('/api/test-email', {
 *       method: 'POST',
 *       headers: { 'Content-Type': 'application/json' },
 *       body: JSON.stringify({ email, type: 'simple' })
 *     });
 *     const data = await res.json();
 *     
 *     if (data.success) {
 *       alert(`✅ Email envoyé à ${data.email_masked}`);
 *     } else {
 *       alert(`❌ Erreur: ${data.error}`);
 *       console.log('Détails:', data.details);
 *     }
 *   } catch (err) {
 *     alert(`Erreur réseau: ${err.message}`);
 *   }
 * }
 * 
 * // Appeler depuis console ou bouton
 * testSendGrid('test@example.com');
 */
