// ============================================================
// À AJOUTER dans api/notifier.js (avant la fonction sendEmail)
// Environ ligne 150
// ============================================================

async function sendAuthConfirmationEmail(data, config) {
  /**
   * Envoie un email de confirmation d'auth (signup ou resend)
   * Utilisé quand Supabase ne peut pas envoyer ou en fallback
   * 
   * Params:
   *   data: { email, prenom?, nom?, lien_confirmation? }
   *   config: { sendgridKey, fromEmail, fromName }
   */
  const { email, prenom = 'Ami', lien_confirmation = '' } = data || {};
  
  if (!email) {
    return { ok: false, error: 'Email requis pour confirmation' };
  }

  const html = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #0A0C0F; color: #E8EAED; margin: 0; padding: 20px;">
    <div style="max-width: 600px; margin: 0 auto; background: #12151A; border: 1px solid #1F242C; border-radius: 12px; overflow: hidden;">
        <!-- Header -->
        <div style="background: linear-gradient(135deg, #B8F53E 0%, #0BFFCB 100%); padding: 40px 20px; text-align: center;">
            <div style="font-size: 2.5rem; margin-bottom: 10px;">🚗</div>
            <h1 style="color: #0A0C0F; margin: 0; font-size: 28px; font-weight: 800;">PorteàPorte</h1>
            <p style="color: rgba(10, 12, 15, 0.7); margin: 5px 0 0; font-size: 14px;">La livraison collaborative québécoise</p>
        </div>

        <!-- Content -->
        <div style="padding: 40px 30px;">
            <h2 style="color: #E8EAED; margin: 0 0 20px; font-size: 22px; font-weight: 700;">Confirme ton email, ${prenom}! ✅</h2>
            
            <p style="color: #A0A3A8; line-height: 1.7; margin: 0 0 20px; font-size: 15px;">
                Bienvenue chez PorteàPorte! Pour compléter ton inscription, clique sur le bouton ci-dessous pour confirmer ton adresse email.
            </p>

            <p style="color: #A0A3A8; line-height: 1.7; margin: 0 0 30px; font-size: 15px;">
                Ce lien expire dans <strong>24 heures</strong>.
            </p>

            <!-- CTA Button -->
            <div style="text-align: center; margin: 30px 0;">
                <a href="${lien_confirmation || 'https://porteaporte.site/login.html'}" 
                   style="background: #B8F53E; color: #0A0C0F; padding: 14px 40px; border-radius: 8px; text-decoration: none; font-weight: 800; font-size: 16px; display: inline-block; border: 2px solid #B8F53E; transition: all 0.3s ease;">
                    Confirmer mon email →
                </a>
            </div>

            <div style="background: rgba(184, 245, 62, 0.1); border-left: 4px solid #B8F53E; padding: 15px; margin: 30px 0; border-radius: 4px;">
                <p style="color: #E8EAED; margin: 0; font-size: 13px; font-weight: 600;">
                    🔒 Lien personnel et sécurisé
                </p>
                <p style="color: #A0A3A8; margin: 8px 0 0; font-size: 12px; line-height: 1.6;">
                    Ne partage ce lien avec personne. PorteàPorte ne te demandera jamais ton mot de passe par email.
                </p>
            </div>

            <p style="color: #A0A3A8; line-height: 1.7; margin: 30px 0 0; font-size: 13px;">
                Si le bouton ne fonctionne pas, tu peux aussi copier-coller ce lien dans ton navigateur:<br>
                <code style="background: rgba(255,255,255,0.05); padding: 6px 10px; border-radius: 4px; word-break: break-all; display: inline-block; margin-top: 8px; font-size: 11px;">
                    ${lien_confirmation || 'https://porteaporte.site/login.html?confirmed=1'}
                </code>
            </p>

            <hr style="border: none; border-top: 1px solid #1F242C; margin: 30px 0;">

            <p style="color: #888; font-size: 12px; margin: 0; text-align: center; line-height: 1.6;">
                Des questions? Contacte notre support:<br>
                <a href="mailto:support@porteaporte.site" style="color: #B8F53E; text-decoration: none;">support@porteaporte.site</a>
            </p>
        </div>

        <!-- Footer -->
        <div style="background: rgba(0,0,0,0.2); padding: 20px; text-align: center; font-size: 11px; color: #888;">
            <p style="margin: 0;">© 2024-2025 PorteàPorte · La livraison collaborative québécoise 🍁</p>
            <p style="margin: 5px 0 0;">Ce courriel a été généré automatiquement. Merci de ne pas répondre.</p>
        </div>
    </div>
</body>
</html>
  `.trim();

  try {
    const response = await sendEmail({
      to: email,
      subject: 'Confirme ton email - PorteàPorte ✅',
      html,
      from: config.fromEmail,
      from_name: config.fromName
    }, config.sendgridKey);

    return response;
  } catch (err) {
    console.error('[sendAuthConfirmationEmail] Erreur SendGrid:', err.message);
    return { ok: false, error: err.message };
  }
}

// ============================================================
// INTÉGRATION: Remplacer la ligne 124-135 dans api/notifier.js
// ============================================================

// AVANT (ligne 124-135):
/*
    if (type === 'auth_confirmation') {
      const result = await sendAuthConfirmationEmail(data, {
        sendgridKey: SENDGRID_API_KEY,
        fromEmail: FROM_EMAIL,
        fromName: FROM_NAME
      });
      return res.status(result.ok ? 200 : 500).json({
        success: result.ok,
        sent: result.ok ? 1 : 0,
        error: result.ok ? undefined : 'Courriel de confirmation non envoye'
      });
    }
*/

// APRÈS (changement minimal):
/*
    if (type === 'auth_confirmation') {
      // Utiliser sendAuthConfirmationEmail pour envoyer directement
      const result = await sendAuthConfirmationEmail(data, {
        sendgridKey: SENDGRID_API_KEY,
        fromEmail: FROM_EMAIL,
        fromName: FROM_NAME
      });
      return res.status(result.ok ? 200 : 500).json({
        success: result.ok,
        sent: result.ok ? 1 : 0,
        error: result.ok ? undefined : (result.error || 'Courriel de confirmation non envoye')
      });
    }
*/

// ============================================================
