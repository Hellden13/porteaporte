/**
 * API: /api/admin-update-driver-status
 * 
 * Endpoint pour que les admins mettent à jour le statut de vérification des livreurs.
 * 
 * Sécurité:
 * - Exige une session admin valide
 * - Vérification par role === 'admin'
 * - Transitions de statut validées
 * - Notification email automatique quand status === 'verified'
 * 
 * Statuts possibles:
 *   not_started     = Livreur créé, aucune action
 *   pending_review  = Documents soumis, en attente approbation
 *   verified        = Approuvé, reçoit carte vérifiée
 *   rejected        = Rejeté, peut réessayer
 *   suspended       = Suspendu (fraude, etc.)
 * 
 * POST /api/admin-update-driver-status
 * Headers: Authorization: Bearer <token>
 * Body: {
 *   user_id: "uuid-of-driver",
 *   driver_status: "verified",
 *   notes?: "Identité vérifiée par admin"
 * }
 * 
 * Réponse: { success: true, updated: { id, email, driver_status, ... } }
 */

async function getSession(req, sbUrl, sbKey) {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  if (!token) return null;
  const r = await fetch(`${sbUrl}/auth/v1/user`, {
    headers: { apikey: sbKey, Authorization: `Bearer ${token}` }
  });
  return r.ok ? r.json() : null;
}

async function getProfile(userId, sbUrl, sbKey) {
  const r = await fetch(
    `${sbUrl}/rest/v1/profiles?id=eq.${userId}&select=id,email,prenom,nom,role,driver_status,suspendu`,
    {
      headers: {
        apikey: sbKey,
        Authorization: `Bearer ${sbKey}`,
        'Content-Type': 'application/json',
      },
    }
  );
  const rows = r.ok ? await r.json() : [];
  return rows[0] || null;
}

function sbHeaders(key) {
  return {
    apikey: key,
    Authorization: `Bearer ${key}`,
    'Content-Type': 'application/json',
  };
}

async function callNotifier(type, data) {
  const siteOrigin = (process.env.PUBLIC_SITE_ORIGIN || process.env.ALLOWED_ORIGIN || 'https://porteaporte.site').replace(/\/$/, '');
  const headers = { 'Content-Type': 'application/json' };
  const secret = process.env.INTERNAL_API_SECRET;
  if (secret) headers['x-internal-notifier-secret'] = secret;

  const r = await fetch(`${siteOrigin}/api/notifier`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ type, data }),
  });
  const out = await r.json().catch(() => ({}));
  return { ok: r.ok, status: r.status, data: out };
}

module.exports = async function handler(req, res) {
  // CORS
  const allowOrigin = process.env.ALLOWED_ORIGIN || 'https://porteaporte.site';
  res.setHeader('Access-Control-Allow-Origin', allowOrigin);
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Méthode non autorisée' });
  }

  // Config Supabase
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY;

  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
    console.error('[admin-update-driver-status] Supabase config manquante');
    return res.status(500).json({
      error: 'Configuration serveur manquante',
    });
  }

  // Récupérer la session
  const session = await getSession(req, SUPABASE_URL, SUPABASE_ANON_KEY);
  if (!session) {
    return res.status(401).json({ error: 'Non authentifié' });
  }

  // Récupérer le profile admin
  const adminProfile = await getProfile(session.id, SUPABASE_URL, SUPABASE_ANON_KEY);
  if (!adminProfile || adminProfile.role !== 'admin') {
    return res.status(403).json({
      error: 'Accès refusé - Rôle admin requis',
    });
  }

  // Valider les paramètres
  const { user_id, driver_status, notes = '' } = req.body || {};

  if (!user_id || !driver_status) {
    return res.status(400).json({
      error: 'Paramètres requis: user_id, driver_status',
    });
  }

  const allowedStatuses = new Set(['not_started', 'pending_review', 'verified', 'rejected', 'suspended']);
  if (!allowedStatuses.has(driver_status)) {
    return res.status(400).json({
      error: `Statut invalide. Permis: ${[...allowedStatuses].join(', ')}`,
    });
  }

  try {
    // Récupérer le livreur actuel
    const driverProfile = await getProfile(user_id, SUPABASE_URL, SUPABASE_ANON_KEY);
    if (!driverProfile) {
      return res.status(404).json({ error: 'Livreur introuvable' });
    }

    // Préparer la mise à jour
    const patch = {
      driver_status,
      verification_status: driver_status === 'verified' ? 'verified' :
                          driver_status === 'rejected' ? 'rejected' :
                          driver_status === 'suspended' ? 'suspended' : 'pending',
      suspendu: driver_status === 'suspended',
      mis_a_jour_le: new Date().toISOString(),
    };

    // Si notes fourni, ajouter (optionnel selon schema)
    if (notes) {
      patch.verification_notes = notes;
    }

    // PATCH le profile
    const updateRes = await fetch(
      `${SUPABASE_URL}/rest/v1/profiles?id=eq.${encodeURIComponent(user_id)}`,
      {
        method: 'PATCH',
        headers: sbHeaders(SUPABASE_ANON_KEY),
        body: JSON.stringify(patch),
      }
    );

    const updateData = await updateRes.json().catch(() => ({}));

    if (!updateRes.ok) {
      console.error('[admin-update-driver-status] PATCH error:', updateData);
      return res.status(400).json({
        error: 'Mise à jour impossible',
        details: updateData?.message || 'Erreur Supabase',
      });
    }

    const updated = Array.isArray(updateData) ? updateData[0] : updateData;

    // Si verified, envoyer la carte livreur
    if (driver_status === 'verified' && updated?.email) {
      const cardId = 'PP-DR-' + String(updated.id || '').slice(0, 8).toUpperCase();
      const notifyRes = await callNotifier('carte_livreur', {
        user_id: updated.id,
        email: updated.email,
        prenom: updated.prenom || '',
        nom: updated.nom || '',
        ville: updated.ville || '',
        vehicule: updated.vehicule || updated.transport_mode || '',
        transport_mode: updated.transport_mode || '',
        driver_status: 'verified',
        card_id: cardId,
        is_verified: true,
      });

      if (!notifyRes.ok) {
        console.warn('[admin-update-driver-status] Carte livreur notification échouée:', notifyRes.data);
        // Mais ne pas échouer la requête globale
      } else {
        console.log(`[admin-update-driver-status] Carte vérifiée envoyée à ${updated.email}`);
      }
    }

    // Log admin action
    console.log(`[admin-update-driver-status] Admin ${adminProfile.id} a mis à jour ${user_id} → ${driver_status}`);

    // Réponse succès
    return res.status(200).json({
      success: true,
      updated: {
        id: updated.id,
        email: updated.email,
        prenom: updated.prenom,
        nom: updated.nom,
        driver_status: updated.driver_status,
        verification_status: updated.verification_status,
        suspendu: updated.suspendu,
        mis_a_jour_le: updated.mis_a_jour_le,
      },
      message: driver_status === 'verified' 
        ? 'Livreur approuvé - Carte vérifiée envoyée'
        : `Statut mis à jour: ${driver_status}`,
    });

  } catch (err) {
    console.error('[admin-update-driver-status] Exception:', err);
    return res.status(500).json({
      error: 'Erreur interne',
      details: err.message,
    });
  }
};

/**
 * EXEMPLE D'UTILISATION FRONTEND:
 * 
 * async function approveDriver(userId) {
 *   const token = await getAuthToken();  // Depuis Supabase
 *   const res = await fetch('/api/admin-update-driver-status', {
 *     method: 'POST',
 *     headers: {
 *       'Content-Type': 'application/json',
 *       'Authorization': `Bearer ${token}`
 *     },
 *     body: JSON.stringify({
 *       user_id: userId,
 *       driver_status: 'verified',
 *       notes: 'Identité vérifiée, documents conformes'
 *     })
 *   });
 *   const data = await res.json();
 *   if (data.success) {
 *     console.log('✅ Livreur approuvé:', data.updated.email);
 *     // Recharger dashboard admin
 *   } else {
 *     alert('Erreur: ' + data.error);
 *   }
 * }
 */
